<?php

class Pengajuan_rekom extends CI_Controller{
public function index(){
    $data['title'] ="Pengajuan Rekomendasi Solar";
    $this->load->model('Peng_rekom_model');
    $data ['rekomendasi']= $this->Peng_rekom_model->get_data()->result();
    $this->load->view('templates_administrator/header', $data);
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/pengajuan_rekom', $data);
    $this->load->view('templates_administrator/footer');
}

//CONTROLLER TAMBAH DATA 
public function tambah_peng_solar()
{
    $data['title'] = "Tambah Pengajuan Solar";
    $this->load->view('templates_administrator/header', $data);
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('administrator/tambah_peng_solar', $data);
    $this->load->view('templates_administrator/footer');
}
public function tambah_data_aksi() 
{ 
    $this->_rules();
    if($this->form_validation->run() == FALSE) { 
        $this->tambah_tdg();
    } else{
        $no_surat   = $this->input->post('no_surat');
        $nama_pemilik   = $this->input->post('nama_pemilik');
        $nik   = $this->input->post('nik');
        $alamat   = $this->input->post('alamat');
        $telp   = $this->input->post('telp');
        $nama_usaha   = $this->input->post('nama_usaha');
        $jenis_usaha   = $this->input->post('jenis_usaha');
        $upload_sku  = $this->input->post('upload_sku');
        $up_mesin_tempat   = $this->input->post('up_mesin_tempat');
        $up_surat_pengajuan   = $this->input->post('up_surat_pengajuan');

        $data = array(
            'no_surat' => $no_surat,
            'nama_pemilik' => $nama_pemilik,
            'nik' => $nik,
            'alamat' => $alamat,
            'telp' => $telp,
            'nama_usaha' => $nama_usaha,
            'jenis_usaha' => $jenis_usaha,
            'upload_sku' => $upload_sku,
            'up_mesin_tempat' => $up_mesin_tempat,
            'up_surat_pengajuan' => $up_surat_pengajuan,
        );
        $this->peng_rekom_model->insert_data($data, 'rekomendasi');
         //memunculkan alerts untuk pesan alert nya diambil di bootsstrap
         $this->session->set_flashdata('pesan','<div class="alert alert-success alert-dismissible fade show" role="alert">
         <strong>Data Berhasil Ditambahkan!</strong>
         <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
         </div>');
         redirect('administrator/pengajuan_rekom');
        

    }
}

//tambah pengajuan lama 
//UPDATE DTG

public function _rules()
    {
        $this->form_validation->set_rules('nama_pemilik','Nama Pemilik','required');
       
    }
}

?>