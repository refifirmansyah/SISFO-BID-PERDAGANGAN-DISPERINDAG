<?php

class kgb extends CI_Controller{
public function index(){
    $data['title'] ="Kenaikan Gaji Berkala";
    $data['jabatan']=$this->kgb_model->get_data('data_pegawai')->result();
    $this->load->view('templates_administrator/header', $data);
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('Administrator/kgb', $data);
    $this->load->view('templates_administrator/footer');
}

}

?>