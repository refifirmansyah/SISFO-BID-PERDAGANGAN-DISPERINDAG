<?php

class pengajuan_pensiun extends CI_Controller{
public function index(){
    $data['title'] ="Pengajuan Pensiun";
    $data['pengajuan']=$this->kgb_model->get_data('data_pegawai')->result();
    $this->load->view('templates_administrator/header', $data);
    $this->load->view('templates_administrator/sidebar');
    $this->load->view('Administrator/pengajuan_pensiun', $data);
    $this->load->view('templates_administrator/footer');
}

}

?>