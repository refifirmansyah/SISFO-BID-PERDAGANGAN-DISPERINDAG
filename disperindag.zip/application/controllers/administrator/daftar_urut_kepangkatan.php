<?php

class Daftar_urut_kepangkatan extends CI_Controller
{
    public function index()
    {
        $data['title'] = "Daftar Urut Kepangkatan";
        $data['daftar_pangkat'] = $this->daftar_urut_pangkat_model->get_data('data_pegawai')->result();
        $this->load->view('templates_administrator/header', $data);
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('Administrator/daftar_urut_kepangkatan', $data);
        $this->load->view('templates_administrator/footer');
    }

    //CONTROLLER TAMBAH DATA 
    public function tambah_data_pegawai()
    {
        $data['title'] = "Tambah Data Pegawai";
        $this->load->view('templates_administrator/header', $data);
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/tambah_data_pegawai', $data);
        $this->load->view('templates_administrator/footer');
    }

    //Controller tambah data aksi
    public function tambah_data_aksi()
    {
        // Rules pada form
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->tambah_data_pegawai();
        } else {
            // Tangkap data dengan method post
            $nama                       = $this->input->post('nama');
            $nip                        = $this->input->post('nip');
            $telepon                    = $this->input->post('telepon');
            $pangkat_gol_ruang          = $this->input->post('pangkat_gol_ruang');
            $jabatan                    = $this->input->post('jabatan');
            $eselon                     = $this->input->post('eselon');
            $unit_bidang                = $this->input->post('unit_bidang');
            $bidang                     = $this->input->post('bidang');
            $no_karpeg                  = $this->input->post('no_karpeg');
            $nomor_seri_kepegawaian     = $this->input->post('nomor_seri_kepegawaian');
            $golongan_gaji              = $this->input->post('golongan_gaji');
            $jabatan_dinas              = $this->input->post('jabatan_dinas');
            $gol_awal                   = $this->input->post('gol_awal');
            $tmt_awal                   = $this->input->post('tmt_awal');
            $gol_akhir                  = $this->input->post('gol_akhir');
            $tmt_akhir                  = $this->input->post('tmt_akhir');
            $tmt_jabatan                = $this->input->post('tmt_jabatan');
            $pendidikan                 = $this->input->post('pendidikan');
            $jurusan                    = $this->input->post('jurusan');
            $sekolah                    = $this->input->post('sekolah');
            $lulus                      = $this->input->post('lulus');
            $tempat_lahir               = $this->input->post('tempat_lahir');
            $tanggal_lahir              = $this->input->post('tanggal_lahir');
            $jenis_kelamin              = $this->input->post('jenis_kelamin');
            $agama                      = $this->input->post('agama');
            $status_perkawinan          = $this->input->post('status_perkawinan');
            $jalan_kampung              = $this->input->post('jalan_kampung');
            $rt                         = $this->input->post('rt');
            $rw                         = $this->input->post('rw');
            $kelurahan_desa             = $this->input->post('kelurahan_desa');
            $kecamatan                  = $this->input->post('kecamatan');
            $kabupaten                  = $this->input->post('kabupaten');
            $kota                       = $this->input->post('kota');
            $telepon                    = $this->input->post('telepon');
            $penghargaan                = $this->input->post('penghargaan');
            $keterangan                 = $this->input->post('keterangan');

            // Simpan data di Array
            $data = array(
                'nama' => $nama,
                'nip' => $nip,
                'telepon' => $telepon,
                'pangkat_gol_ruang' => $pangkat_gol_ruang,
                'jabatan' => $jabatan,
                'eselon' => $eselon,
                'unit_bidang' => $unit_bidang,
                'bidang' => $bidang,
                'no_karpeg' => $no_karpeg,
                'nomor_seri_kepegawaian' => $nomor_seri_kepegawaian,
                'golongan_gaji' => $golongan_gaji,
                'jabatan_dinas' => $jabatan_dinas,
                'gol_awal' => $gol_awal,
                'tmt_awal' => $tmt_awal,
                'gol_akhir' => $gol_akhir,
                'tmt_akhir' => $tmt_akhir,
                'tmt_jabatan' => $tmt_jabatan,
                'pendidikan' => $pendidikan,
                'jurusan' => $jurusan,
                'sekolah' => $sekolah,
                'lulus' => $lulus,
                'tempat_lahir' => $tempat_lahir,
                'tanggal_lahir' => $tanggal_lahir,
                'jenis_kelamin' => $jenis_kelamin,
                'agama' => $agama,
                'status_perkawinan' => $status_perkawinan,
                'jalan_kampung' => $jalan_kampung,
                'rt' => $rt,
                'rw' => $rw,
                'kelurahan_desa' => $kelurahan_desa,
                'kecamatan' => $kecamatan,
                'kabupaten' => $kabupaten,
                'kota' => $kota,
                'telepon' => $telepon,
                'penghargaan' => $penghargaan,
                'keterangan' => $keterangan,
            );

            // Data disimpan ke database di table data_pegawai
            $this->daftar_urut_pangkat_model->insert_data($data, 'data_pegawai');
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data Berhasil Disimpan!</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>');
            // redirect ke nama class di controller
            redirect('administrator/daftar_urut_kepangkatan');
        }
    }

    //CONTROLLER UPDATE DATA 
    public function update_data_pegawai($id)
    {
        $where = array('id_pegawai' => $id);
        $data['daftar_pangkat'] = $this->db->query("SELECT * FROM data_pegawai WHERE id_pegawai='$id'")->result();
        $data['title'] = "Update Data Pegawai";
        $this->load->view('templates_administrator/header', $data);
        $this->load->view('templates_administrator/sidebar');
        $this->load->view('administrator/update_data_pegawai', $data);
        $this->load->view('templates_administrator/footer');
    }

    //Controller tambah data aksi
    public function update_data_aksi()
    {
        //function rulesform
        $this->_rules();
        //jika form validation nya = false
        if ($this->form_validation->run() == FALSE) {
            $this->update_data_pegawai();
        } else {
            // Tangkap data dengan method post
            $id                        = $this->input->post('id_pegawai');
            $nama                      = $this->input->post('nama');
            $nip                       = $this->input->post('nip');
            $telepon                   = $this->input->post('telepon');
            $pangkat_gol_ruang         = $this->input->post('pangkat_gol_ruang');
            $jabatan                   = $this->input->post('jabatan');
            $eselon                    = $this->input->post('eselon');
            $unit_bidang               = $this->input->post('unit_bidang');
            $bidang                    = $this->input->post('bidang');
            $no_karpeg                 = $this->input->post('no_karpeg');
            $nomor_seri_kepegawaian    = $this->input->post('nomor_seri_kepegawaian');
            $golongan_gaji             = $this->input->post('golongan_gaji');
            $jabatan_dinas             = $this->input->post('jabatan_dinas');
            $gol_awal                  = $this->input->post('gol_awal');
            $tmt_awal                  = $this->input->post('tmt_awal');
            $gol_akhir                 = $this->input->post('gol_akhir');
            $tmt_akhir                 = $this->input->post('tmt_akhir');
            $tmt_jabatan               = $this->input->post('tmt_jabatan');
            $pendidikan                = $this->input->post('pendidikan');
            $jurusan                   = $this->input->post('jurusan');
            $sekolah                   = $this->input->post('sekolah');
            $lulus                     = $this->input->post('lulus');
            $tempat_lahir              = $this->input->post('tempat_lahir');
            $tanggal_lahir             = $this->input->post('tanggal_lahir');
            $jenis_kelamin             = $this->input->post('jenis_kelamin');
            $agama                     = $this->input->post('agama');
            $status_perkawinan         = $this->input->post('status_perkawinan');
            $jalan_kampung             = $this->input->post('jalan_kampung');
            $rt                        = $this->input->post('rt');
            $rw                        = $this->input->post('rw');
            $kelurahan_desa            = $this->input->post('kelurahan_desa');
            $kecamatan                 = $this->input->post('kecamatan');
            $kabupaten                 = $this->input->post('kabupaten');
            $kota                      = $this->input->post('kota');
            $telepon                   = $this->input->post('telepon');
            $penghargaan               = $this->input->post('penghargaan');
            $keterangan                = $this->input->post('keterangan');

            // Simpan data di Array
            $data = array(
                'nama' => $nama,
                'nip' => $nip,
                'telepon' => $telepon,
                'pangkat_gol_ruang' => $pangkat_gol_ruang,
                'jabatan' => $jabatan,
                'eselon' => $eselon,
                'unit_bidang' => $unit_bidang,
                'bidang' => $bidang,
                'no_karpeg' => $no_karpeg,
                'nomor_seri_kepegawaian' => $nomor_seri_kepegawaian,
                'golongan_gaji' => $golongan_gaji,
                'jabatan_dinas' => $jabatan_dinas,
                'gol_awal' => $gol_awal,
                'tmt_awal' => $tmt_awal,
                'gol_akhir' => $gol_akhir,
                'tmt_akhir' => $tmt_akhir,
                'tmt_jabatan' => $tmt_jabatan,
                'pendidikan' => $pendidikan,
                'jurusan' => $jurusan,
                'sekolah' => $sekolah,
                'lulus' => $lulus,
                'tempat_lahir' => $tempat_lahir,
                'tanggal_lahir' => $tanggal_lahir,
                'jenis_kelamin' => $jenis_kelamin,
                'agama' => $agama,
                'status_perkawinan' => $status_perkawinan,
                'jalan_kampung' => $jalan_kampung,
                'rt' => $rt,
                'rw' => $rw,
                'kelurahan_desa' => $kelurahan_desa,
                'kecamatan' => $kecamatan,
                'kabupaten' => $kabupaten,
                'kota' => $kota,
                'telepon' => $telepon,
                'penghargaan' => $penghargaan,
                'keterangan' => $keterangan,
            );

            $where = array(
                'id_pegawai' => $id
            );

            //query untuk menyinmpan data panggil dahulu model
            $this->daftar_urut_pangkat_model->update_data('data_pegawai', $data, $where);
            //memunculkan alerts untuk pesan alert nya diambil di bootsstrap
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Data Berhasil Diupdate!</strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>');
            redirect('administrator/daftar_urut_kepangkatan');
        }
    }

    // Menetukan rules dari input form
    public function _rules()
    {
        $this->form_validation->set_rules('nama', 'nama', 'required');
        $this->form_validation->set_rules('nip', 'nip', 'required');
        $this->form_validation->set_rules('telepon', 'telepon', 'required');
        $this->form_validation->set_rules('pangkat_gol_ruang', 'pangkat gol ruang', 'required');
        $this->form_validation->set_rules('jabatan', 'jabatan', 'required');
        $this->form_validation->set_rules('eselon', 'eselon', 'required');
        $this->form_validation->set_rules('unit_bidang', 'unit bidang', 'required');
        $this->form_validation->set_rules('bidang', 'bidang', 'required');
        $this->form_validation->set_rules('no_karpeg', 'no karpeg', 'required');
        $this->form_validation->set_rules('nomor_seri_kepegawaian', 'nomor seri kepegewaian', 'required');
        $this->form_validation->set_rules('golongan_gaji', 'golongan gaji', 'required');
        $this->form_validation->set_rules('jabatan_dinas', 'jabatan dinas', 'required');
        $this->form_validation->set_rules('gol_awal', 'gol awal', 'required');
        $this->form_validation->set_rules('tmt_awal', 'tmt awal', 'required');
        $this->form_validation->set_rules('gol_akhir', 'gol akhir', 'required');
        $this->form_validation->set_rules('tmt_akhir', 'tmt akhir', 'required');
        $this->form_validation->set_rules('tmt_jabatan', 'tmt jabatan', 'required');
        $this->form_validation->set_rules('pendidikan', 'pendidikan', 'required');
        $this->form_validation->set_rules('jurusan', 'jurusan', 'required');
        $this->form_validation->set_rules('sekolah', 'sekolah', 'required');
        $this->form_validation->set_rules('lulus', 'lulus', 'required');
        $this->form_validation->set_rules('tempat_lahir', 'tempat lahir', 'required');
        $this->form_validation->set_rules('tanggal_lahir', 'tanggal lahir', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'jenis', 'required');
        $this->form_validation->set_rules('agama', 'agama', 'required');
        $this->form_validation->set_rules('status_perkawinan', 'status_perkawinan', 'required');
        $this->form_validation->set_rules('jalan_kampung', 'jalan_kampung', 'required');
        $this->form_validation->set_rules('rt', 'rt', 'required');
        $this->form_validation->set_rules('rw', 'rw', 'required');
        $this->form_validation->set_rules('kelurahan_desa', 'kelurahan desa', 'required');
        $this->form_validation->set_rules('kecamatan', 'kecamatan', 'required');
        $this->form_validation->set_rules('kabupaten', 'kabupaten', 'required');
        $this->form_validation->set_rules('kota', 'kota', 'required');
        $this->form_validation->set_rules('telepon', 'telepon', 'required');
        $this->form_validation->set_rules('penghargaan', 'penghargaan', 'required');
        $this->form_validation->set_rules('keterangan', 'keterangan', 'required');
    }

    //CONTROLLER DELETE
    public function delete_data($id)
    {
        $where = array('id_pegawai' => $id);
        $this->daftar_urut_pangkat_model->delete_data($where, 'data_pegawai');
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Data Berhasil Dihapus</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        </div>');
        redirect('administrator/daftar_urut_kepangkatan');
    }
}
