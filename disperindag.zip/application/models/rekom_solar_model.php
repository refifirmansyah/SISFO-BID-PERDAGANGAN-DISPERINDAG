<?php
class Rekom_solar_model extends CI_Model
{
    public function get_data(){
        $this->db->select('*');
        $this->db->from('rekomendasi');
        $this->db->join('kebutuhan_bbm', 'rekomendasi.id_rekomendasi = kebutuhan_bbm.id_rekomendasi');
    return $this->db->get('');
}

//Tambah Data Solar Model 
public function insert_data($rekomendasi_input_data, $kebutuhan_bbm_input_data)
{
    // Table Rekomendasi
    $this->db->insert('rekomendasi', $rekomendasi_input_data);
    $id_rekomendasi = $this->db->insert_id();

    // Table Kebutuhan BBM
    foreach ($kebutuhan_bbm_input_data as $kebutuhan_bbm) {
        $kebutuhan_bbm['id_rekomendasi'] = $id_rekomendasi;
        $this->db->insert('kebutuhan_bbm', $kebutuhan_bbm);
    }

    return $id_rekomendasi;
}

 // UPDATE DATA SOLAR MODEL
 

 //DELETE DATA 
 public function delete_data($id_rekomendasi)
 {
     // Delete data from 'kebutuhan_bbm' table first
     $this->db->where('id_rekomendasi', $id_rekomendasi);
     $this->db->delete('kebutuhan_bbm');

     // Delete data from 'rekomendasi' table
     $this->db->where('id_rekomendasi', $id_rekomendasi);
     $this->db->delete('rekomendasi');
 }

}
?>