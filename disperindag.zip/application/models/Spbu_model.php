<?php

class Spbu_model extends CI_model{

     public function get_spbu_data()
     {
         $query = $this->db->get('spbu');
     
         if ($query->num_rows() > 0) {
             return $query->result(); // Return SPBU data as an array of objects
         } else {
             return array(); // Return empty array if no SPBU data found
         }
     }
     public function get_spbu_details($spbuId)
    {
        // Query to retrieve SPBU details based on $spbuId
        // Replace 'spbu_table' with your actual SPBU table name
        $query = $this->db->get_where('spbu', array('id_spbu' => $spbuId));

        if ($query->num_rows() > 0) {
            return $query->row_array(); // Return SPBU details as an associative array
        } else {
            return array(); // Return empty array if SPBU not found
        }
    }
     
}

?>