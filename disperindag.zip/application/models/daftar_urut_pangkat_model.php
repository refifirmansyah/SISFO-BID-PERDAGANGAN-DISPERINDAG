<?php 
//model untuk Read data pada database
    class Daftar_urut_pangkat_model extends CI_model{ 
        public function get_data($table){ 
            return $this->db->get($table);
        }

    //model untuk insert data 
    public function insert_data($data, $table){ 
        $this->db->insert($table, $data);
    }
    //UPDATE DATA
    public function update_data($table, $data, $where){ 
        $this->db->update($table, $data, $where);
    }
    //delete data
    public function delete_data($where,$table){ 
        $this->db->where($where);
        $this->db->delete($table);
    }

}

?>