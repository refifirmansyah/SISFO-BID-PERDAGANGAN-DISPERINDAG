<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?>
        </h1>
    </div>

    <div class="card" style="width: 60%">
        <div class="card-body">
            <!-- FORM INPUT DATA -->
            <form method="POST" action="<?php echo base_url('administrator/daftar_urut_kepangkatan/tambah_data_aksi') ?>">
                <div class="form-group">
                    <label>NIP</label>
                    <input type="text" name="nip" class="form-control">
                    <?php echo form_error('nip', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control">
                    <?php echo form_error('nama', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Pangkat/Golongan Ruang</label>
                    <select name="pangkat_gol_ruang" class="form-control">
                        <option value="" style="display:none;">Pilih Pangkat/Golongan Ruang</option>
                        <option value="Juru Muda I/A">Juru Muda I/A</option>
                        <option value="Juru Muda Tk I I/B">Juru Muda Tk I I/B</option>
                        <option value="Juru I/C">Juru I/C</option>
                        <option value="Juru Tk I I/D">Juru Tk I I/D</option>
                        <option value="Pengatur Muda II/A">Pengatur Muda II/A</option>
                        <option value="Pengatur Muda Tk I II/B">Pengatur Muda Tk I II/B</option>
                        <option value="Pengatur  II/C">Pengatur II/C</option>
                        <option value="Pengatur Tk I, II/d">Pengatur Tk I, II/d</option>
                        <option value="Penata Tk I II/D">Penata Tk I II/D</option>
                        <option value="Penata Muda III/A">Penata Muda III/A</option>
                        <option value="Penata III/C">Penata III/C</option>
                        <option value="Penata Muda Tk I III/D">Penata Muda Tk I III/D</option>
                        <option value="Pembina IV/A">Pembina IV/A</option>
                        <option value="Pembina Tk I IV/B">Pembina Tk I IV/B</option>
                        <option value="Pembina utama muda IV/C">Pembina utama muda IV/C</option>
                        <option value="Pembina utama madya IV/D">Pembina utama madya IV/D</option>
                        <option value="Pembina utama IV/E">Pembina utama IV/E</option>
                    </select>
                    <?php echo form_error('pangkat_gol_ruang', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Jabatan</label>
                    <select name="jabatan" class="form-control">
                        <option value="" style="display:none;">Pilih Jabatan Dinas</option>
                        <option value="Kepala Dinas">Kepala Dinas</option>
                        <option value="Sekretaris">Sekretaris</option>
                        <option value="Kepala Bidang Pembangunan Sumber Daya Industri">Kepala Bidang Pembangunan Sumber Daya Industri</option>
                        <option value="Kepala Bidang Sarana Dan Prasarana Pemberdayaan Industri">Kepala Bidang Sarana Dan Prasarana Pemberdayaan Industri</option>
                        <option value="Kepala Bidang Perdagangan">Kepala Bidang Perdagangan</option>
                        <option value="Kepala Bidang Pengembangan Promosi Dan Perdagangan">Kepala Bidang Pengembangan Promosi Dan Perdagangan</option>
                        <option value="Kepala Bidang Pasar">Kepala Bidang Pasar</option>
                        <option value="Kepala Sub Bagian Umum Dan Kepegawaian">Kepala Sub Bagian Umum Dan Kepegawaian</option>
                        <option value="Kepala Sub Bagian Keuangan Dan BMD">Kepala Sub Bagian Keuangan Dan BMD</option>
                        <option value="Perencana Ahli Mud">Perencana Ahli Muda</option>
                        <option value="Pengawas Kemotrologian">Pengawas Kemotrologian</option>
                        <option value="Analis Perdagangan Ahli Muda">Analis Perdagangan Ahli Muda</option>
                        <option value="Pengawas Perdagangan Ahli Muda">Pengawas Perdagangan Ahli Muda</option>
                        <option value="Kepala UPT Disperindag ESDM Wil V">Kepala UPT Disperindag ESDM Wil V</option>
                        <option value="Ka. Subbag TU UPT Disperindag ESDM Wil IV">Ka. Subbag TU UPT Disperindag ESDM Wil IV</option>
                        <option value="Bendahara Pengeluaran Pembantu">Bendahara Pengeluaran Pembantu</option>
                        <option value="Penyuluh Perindag Utama">Penyuluh Perindag Utama</option>
                        <option value="Verifikator Anggaran">Verifikator Anggaran</option>
                        <option value="Juru Pungut Retribusi">Juru Pungut Retribusi</option>
                        <option value="Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk">Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk</option>
                        <option value="Pengelola Kepegawaian">Pengelola Kepegawaian</option>
                        <option value="Pengelola Pameran Dan Peragaan Pd Seksi Perdagangan">Pengelola Pameran Dan Peragaan Pd Seksi Perdagangan</option>
                        <option value="Penyusun Rencana Kegiatan & Anggaran Pd Sub BAgian PEP">Penyusun Rencana Kegiatan & Anggaran Pd Sub BAgian PEP</option>
                        <option value="Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk">Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk</option>
                        <option value="Pengelola Keuangan Pd Sub Bagian Keuangan Dan BMD">Pengelola Keuangan Pd Sub Bagian Keuangan Dan BMD</option>
                        <option value="Pengolah Data">Pengolah Data</option>
                        <option value="Pengurus Aset Barang Milik Daerah">Pengurus Aset Barang Milik Daerah</option>
                        <option value="Pengelola Keuangan">Pengelola Keuangan</option>
                        <option value="Analis Perdagangan Ahli Muda">Penata Laporan Keuangan</option>
                        <option value="Ahli Pertama Pranata Komputer">Ahli Pertama Pranata Komputer</option>
                        <option value="Analis Industri">Analis Industri</option>
                        <option value="Penyusun Rencana Kebutuhan Rumahh Tangga Dan Perlengkapan">Penyusun Rencana Kebutuhan Rumahh Tangga Dan Perlengkapan</option>
                        <option value="Kepala Sub Bagian Tata Usaha UPT Wilayah XIV">Kepala Sub Bagian Tata Usaha UPT Wilayah XIV</option>
                        <option value="Juru Pungut Retribusi">Juru Pungut Retribusi pada UPT Kec. Wanaraja</option>
                        <option value="Penera">Penera</option>
                        <option value="Pengadministrasi Karcis">Pengadministrasi Karcis</option>
                        <option value="Bendahara Pengeluaran">Bendahara Pengeluaran</option>
                        <option value="Analis Industri Logam Mesin Elektronik Dan Bahan Bangunan">Analis Industri Logam Mesin Elektronik Dan Bahan Bangunan</option>
                        <option value="Pelaksana">Pelaksana</option>
                    </select>
                    <?php echo form_error('jabatan', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Eselon</label>
                    <select name="eselon" class="form-control">
                        <option value="" style="display:none;">Pilih Eselon</option>
                        <option value="II.a">II.a</option>
                        <option value="II.b">II.b</option>
                        <option value="III.a">III.a</option>
                        <option value="III.b">III.b</option>
                        <option value="IV.a">IV.a</option>
                        <option value="IV.b">IV.b</option>
                    </select>
                    <?php echo form_error('eselon', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Unit Bidang</label>
                    <select name="unit_bidang" class="form-control">
                        <option value="" style="display:none;">Pilih Unit Bidang</option>
                        <option value="Kepala Subbagian Perencanaan, Evaluasi Dan Pelaporan">Kepala Subbagian Perencanaan, Evaluasi Dan Pelaporan</option>
                        <option value="Kepala Subbagian Umum Dan Kepegawaian">Kepala Subbagian Umum Dan Kepegawaian</option>
                        <option value="Kepala Subbagian Keuangan Dan BMD">Kepala Subbagian Keuangan Dan BMD</option>
                        <option value="Kepala Seksi Industri Pangan">Kepala Seksi Industri Pangan</option>
                        <option value="Kepala Seksi Industri Hasil Pertanian">Kepala Seksi Industri Hasil Pertanian</option>
                        <option value="Kepala Seksi Hasil Hutan Dan Hasil Laut">Kepala Seksi Hasil Hutan Dan Hasil Laut</option>
                        <option value="Kepala Seksi Indutri Tekstil, Kulit, Kimia, Alas Kaki Dan Aneka">Kepala Seksi Indutri Tekstil, Kulit, Kimia, Alas Kaki Dan Aneka</option>
                        <option value="Kepala Seksi Industri Logam, Mesin, Elektronika Dan Bahan Bangunan">Kepala Seksi Industri Logam, Mesin, Elektronika Dan Bahan Bangunan</option>
                        <option value="Kepala Seksi Pemanfaatan Energi Sumberdaya Mineral">Kepala Seksi Pemanfaatan Energi Sumberdaya Mineral</option>
                        <option value="Kepala Seksi Pengadaan Dan Penyaluran">Kepala Seksi Pengadaan Dan Penyaluran</option>
                        <option value="Kepala Seksi Sarana Dan Prasarana">Kepala Seksi Sarana Dan Prasarana</option>
                        <option value="Kepala Seksi Kemotrologian">Kepala Seksi Kemotrologian</option>
                        <option value="Kepala Seksi Promosi Perdagangan">Kepala Seksi Promosi Perdagangan</option>
                        <option value="Kepala Seksi Bina Usaha">Kepala Seksi Bina Usaha</option>
                        <option value="Kepala Seksi Kelembagaan Usaha">Kepala Seksi Kelembagaan Usaha</option>
                        <option value="Kepala Seksi Pengelolaan Pendapatan">Kepala Seksi Pengelolaan Pendapatan</option>
                        <option value="Kepala Seksi Pengembangan Dan Tata Kelola Pasar">Kepala Seksi Pengembangan Dan Tata Kelola Pasar</option>
                        <option value="Kepala Seksi Kebersihan, Keamanan, Dan Ketertiban">Kepala Seksi Kebersihan, Keamanan, Dan Ketertiban</option>
                        <option value="Kepala UPT Cikajang">Kepala UPT Cikajang</option>
                        <option value="Kepala UPT Bayongbong">Kepala UPT Bayongbong</option>
                        <option value="Kepala UPT Cisurupan">Kepala UPT Cisurupan</option>
                        <option value="Kepala UPT Limbangan">Kepala UPT Limbangan</option>
                        <option value="Kepala UPT Samarang">Kepala UPT Samarang</option>
                        <option value="Kepala UPT Singajaya">Kepala UPT Singajaya</option>
                        <option value="Kepala UPT Leles">Kepala UPT Leles</option>
                        <option value="Kepala UPT Pameungpeuk">Kepala UPT Pameungpeuk</option>
                        <option value="Kepala UPT Wanaraja">Kepala UPT Wanaraja</option>
                        <option value="Kepala UPT Malangbong">Kepala UPT Malangbong</option>
                        <option value="Kepala UPT Cibatu">Kepala UPT Cibatu</option>
                        <option value="Kepala UPT Kadungora">Kepala UPT Kadungora</option>
                        <option value="Kepala UPT Bungbulang">Kepala UPT Bungbulang</option>
                        <option value="Kepala UPT Garut Kota">Kepala UPT Garut Kota</option>
                        <option value="Kepala UPT Banyuresmi">Kepala UPT Banyuresmi</option>
                        <option value="Kepala UPT Karangpawitan">Kepala UPT Karangpawitan</option>
                        <option value="Kepala UPT Sukawening">Kepala UPT Sukawening</option>
                        <option value="Kepala UPT Cilawu">Kepala UPT Cilawu</option>
                        <option value="Kepala UPT Tarogong Kidul">Kepala UPT Tarogong Kidul</option>
                        <option value="Kepala UPT Cisewu">Kepala UPT Cisewu</option>
                        <option value="Kepala UPT Fungsional Tertentu">Kepala UPT Fungsional Tertentu</option>
                    </select>
                    <?php echo form_error('unit_bidang', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Bidang</label>
                    <select name="bidang" class="form-control">
                        <option value="" style="display:none;">Pilih Bidang</option>
                        <option value="Sekretariat">Sekretariat</option>
                        <option value="Bidang Industri Agro">Bidang Industri Agro</option>
                        <option value="Bidang Non Agro Dan ESDM">Bidang Non Agro Dan ESDM</option>
                        <option value="Bidang Pengembangan Usaha Perdagangan">Bidang Pengembangan Usaha Perdagangan</option>
                        <option value="Bidang Pengelolaan Pasar">Bidang Pengelolaan Pasar</option>
                        <option value="UPT">UPT</option>
                        <option value="Fungsional Tertentu">Fungsional Tertentu</option>
                    </select>
                    <?php echo form_error('bidang', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>No Karpeg</label>
                    <input type="text" name="no_karpeg" class="form-control">
                    <?php echo form_error('no_karpeg', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>No Seri Kepegawaian</label>
                    <input type="text" name="nomor_seri_kepegawaian" class="form-control">
                    <?php echo form_error('nomor_seri_kepagawaian', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Golongan Gaji</label>
                    <input type="text" name="golongan_gaji" class="form-control">
                    <?php echo form_error('golongan_gaji', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Jabatan Dinas</label>
                    <select name="jabatan_dinas" class="form-control">
                        <option value="" style="display:none;">Pilih Jabatan Dinas</option>
                        <option value="Pengguna Anggaran">Pengguna Anggaran</option>
                        <option value="Kuasa Pengguna Anggaran">Kuasa Pengguna Anggaran</option>
                        <option value="Pejabat Pelaksana Teknis Kegiatan ">Pejabat Pelaksana Teknis Kegiatan</option>
                        <option value="Bendahara Pengeluaran">Bendahara Pengeluaran</option>
                        <option value="Pembuat Daftar Gaji">Pembuat Daftar Gaji</option>
                        <option value="Bendahara Pengeluaran Pembantu">Bendahara Pengeluaran Pembantu/option>
                        <option value="Penera Madya">Penera Madya</option>
                        <option value="Sekretaris">Sekretaris</option>
                    </select>
                    <?php echo form_error('jabatan_dinas', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Golongan Awal</label>
                    <select name="gol_awal" class="form-control">
                        <option value="" style="display:none;">Pilih Golongan Awal</option>
                        <option value="Juru Muda I/A">Juru Muda I/A</option>
                        <option value="Juru Muda Tk I I/B">Juru Muda Tk I I/B</option>
                        <option value="Juru I/C">Juru I/C</option>
                        <option value="Juru Tk I I/D">Juru Tk I I/D</option>
                        <option value="Pengatur Muda II/A">Pengatur Muda II/A</option>
                        <option value="Pengatur Muda Tk I II/B">Pengatur Muda Tk I II/B</option>
                        <option value="Pengatur  II/C">Pengatur II/C</option>
                        <option value="Pengatur Tk I, II/d">Pengatur Tk I, II/d</option>
                        <option value="Penata Tk I II/D">Penata Tk I II/D</option>
                        <option value="Penata Muda III/A">Penata Muda III/A</option>
                        <option value="Penata III/C">Penata III/C</option>
                        <option value="Penata Muda Tk I III/D">Penata Muda Tk I III/D</option>
                        <option value="Pembina IV/A">Pembina IV/A</option>
                        <option value="Pembina Tk I IV/B">Pembina Tk I IV/B</option>
                        <option value="Pembina utama muda IV/C">Pembina utama muda IV/C</option>
                        <option value="Pembina utama madya IV/D">Pembina utama madya IV/D</option>
                        <option value="Pembina utama IV/E">Pembina utama IV/E</option>
                    </select>
                    <?php echo form_error('gol_awal', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>TMT Awal</label>
                    <input type="date" name="tmt_awal" class="form-control">
                    <?php echo form_error('tmt_awal', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Golongan Akhir</label>
                    <select name="gol_akhir" class="form-control">
                        <option value="" style="display:none;">Pilih Golongan Akhir</option>
                        <option value="Juru Muda I/A">Juru Muda I/A</option>
                        <option value="Juru Muda Tk I I/B">Juru Muda Tk I I/B</option>
                        <option value="Juru I/C">Juru I/C</option>
                        <option value="Juru Tk I I/D">Juru Tk I I/D</option>
                        <option value="Pengatur Muda II/A">Pengatur Muda II/A</option>
                        <option value="Pengatur Muda Tk I II/B">Pengatur Muda Tk I II/B</option>
                        <option value="Pengatur  II/C">Pengatur II/C</option>
                        <option value="Pengatur Tk I, II/d">Pengatur Tk I, II/d</option>
                        <option value="Penata Tk I II/D">Penata Tk I II/D</option>
                        <option value="Penata Muda III/A">Penata Muda III/A</option>
                        <option value="Penata III/C">Penata III/C</option>
                        <option value="Penata Muda Tk I III/D">Penata Muda Tk I III/D</option>
                        <option value="Pembina IV/A">Pembina IV/A</option>
                        <option value="Pembina Tk I IV/B">Pembina Tk I IV/B</option>
                        <option value="Pembina utama muda IV/C">Pembina utama muda IV/C</option>
                        <option value="Pembina utama madya IV/D">Pembina utama madya IV/D</option>
                        <option value="Pembina utama IV/E">Pembina utama IV/E</option>
                    </select>
                    <?php echo form_error('gol_akhir', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>TMT Akhir</label>
                    <input type="date" name="tmt_akhir" class="form-control">
                    <?php echo form_error('tmt_akhir', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>TMT Jabatan</label>
                    <input type="date" name="tmt_jabatan" class="form-control">
                    <?php echo form_error('tmt_jabatan', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Pendidikan</label>
                    <input type="text" name="pendidikan" class="form-control">
                    <?php echo form_error('pendidikan', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Jurusan</label>
                    <input type="text" name="jurusan" class="form-control">
                    <?php echo form_error('jurusan', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Sekolah</label>
                    <input type="text" name="sekolah" class="form-control">
                    <?php echo form_error('sekolah', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Lulus</label>
                    <input type="text" name="lulus" class="form-control">
                    <?php echo form_error('lulus', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="form-control">
                    <?php echo form_error('tempat_lahir', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Tanggal_lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control">
                    <?php echo form_error('tanggal_lahir', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="form-control">
                        <option value="" style="display:none;">Pilih Jenis Kelamin</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                    <?php echo form_error('jenis_kelamin', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Agama</label>
                    <select name="agama" class="form-control">
                        <option value="" style="display:none;">Pilih Agama</option>
                        <option value="Islam">Islam</option>
                        <option value="Kristen">Kristen</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Budha">Budha</option>
                        <option value="Kongghucu">Kongghucu</option>
                    </select>
                    <?php echo form_error('agama', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Status Perkawinan</label>
                    <select name="status_perkawinan" class="form-control">
                        <option value="" style="display:none;">Pilih Status Perkawinan</option>
                        <option value="Tidak Kawin">Tidak Kawin</option>
                        <option value="Kawin">Kawin</option>
                        <option value="Janda">Janda</option>
                        <option value="Duda">Duda</option>
                    </select>
                    <?php echo form_error('status_perkawinan', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Jalan Kampung</label>
                    <input type="text" name="jalan_kampung" class="form-control">
                    <?php echo form_error('jalan_kampung', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>RT</label>
                    <input type="text" name="rt" class="form-control">
                    <?php echo form_error('rt', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>RW</label>
                    <input type="text" name="rw" class="form-control">
                    <?php echo form_error('rw', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Kelurahan Desa</label>
                    <input type="text" name="kelurahan_desa" class="form-control">
                    <?php echo form_error('kelurahan_desa', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Kecamatan</label>
                    <input type="text" name="kecamatan" class="form-control">
                    <?php echo form_error('kecamatan', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Kabupaten</label>
                    <input type="text" name="kabupaten" class="form-control">
                    <?php echo form_error('kabupaten', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Kota</label>
                    <input type="text" name="kota" class="form-control">
                    <?php echo form_error('kota', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Telepon</label>
                    <input type="text" name="telepon" class="form-control">
                    <?php echo form_error('telepon', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Penghargaan</label>
                    <select name="penghargaan" class="form-control">
                        <option value="" style="display:none;">Pilih Penghargaan</option>
                        <option value="Penghargaan Bupati 10 Tahun">Penghargaan Bupati 10 Tahun</option>
                        <option value="Penghargaan Bupati 20 Tahun">Penghargaan Bupati 20 Tahun</option>
                        <option value="Penghargaan Bupati 30 Tahun">Penghargaan Bupati 30 Tahun</option>
                        <option value="Penghargaan Presiden 10 Tahun">Penghargaan Presiden 10 Tahun</option>
                        <option value="Penghargaan Presiden 20 Tahun">Penghargaan Presiden 20 Tahun</option>
                        <option value="Penghargaan Presiden 30 Tahun">Penghargaan Presiden 30 Tahun</option>
                        <option value="Kongghucu">Kongghucu</option>
                    </select>
                    <?php echo form_error('penghargaan', '<div class="text-small text-danger"></div>'); ?>
                </div>

                <div class="form-group">
                    <label>Keterangan</label>
                    <input type="text" name="keterangan" class="form-control">
                    <?php echo form_error('keterangan', '<div class="text-small text-danger"></div>'); ?>
                </div>


                <button type="submit" class="btn btn-success">Submit</button>

            </form>
        </div>
    </div>

</div>