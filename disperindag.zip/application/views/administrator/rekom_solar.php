 <!-- TEMPLATE BUAT BIKIN VIEW -->
 <div class="container-fluid">

     <!-- Page Heading -->
     <div class="d-sm-flex align-items-center justify-content-between mb-4">
         <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?></h1>
     </div>

     <!-- Button Tambah Data  -->
     <a class="btn btn-sm mb-3 btn-success "
         href="<?php echo base_url('administrator/rekom_solar/tambah_data_solar/')?>">
         <i class="fas fa-plus"> Tambah Data</i></a>
     <?php echo $this->session->flashdata('pesan')?>
     <div class="table-responsive">
         <table class="table table-bordered table-striped mt-2">
             <tr>

                 <style>
                 .table-container {
                     overflow-x: auto;
                 }

                 .table-container table {
                     min-width: 100%;
                 }
                 </style>

                 <div class="table-container">
                     <table class="table table-bordered table-striped mt-2">
                         <tr>
                             <th class="text-center"> No</th>
                             <th class="text-center"> No. Surat</th>
                             <th class="text-center"> NIK</th>
                             <th class="text-center"> Nama Pemilik Usaha</th>
                             <th class="text-center"> Alamat Pemilik Usaha</th>
                             <th class="text-center"> No. HP</th>
                             <th class="text-center"> Kosumen Pengguna</th>
                             <th class="text-center"> Nama Usaha</th>
                             <th class="text-center"> Jenis Usaha/Kegiatan</th>
                             <th class="text-center"> Satuan Kebutuhan</th>
                             <th class="text-center"> Tanggal Pengajuan</th>
                             <th class="text-center"> Lembaga Penyalur Tempat Pengambilan</th>
                             <th class="text-center"> Jenis Alat</th>
                             <th class="text-center"> Jumlah Alat (Unit)</th>
                             <th class="text-center"> Fungsi Alat</th>
                             <th class="text-center"> BBM Jenis Tertentu</th>
                             <th class="text-center"> Kebutuhan</th>
                             <th class="text-center"> Durasi Operasi</th>
                             <th class="text-center"> Konsumsi BBM</th>
                             <th class="text-center"> Durasi Konsumsi</th>
                             <th class="text-center"> Jumlah Alokasi</th>
                             <th class="text-center"> Durasi Alokasi</th>
                             <th class="text-center"> Masa Berlaku</th>
                             <th class="text-center"> Nomor Lembaga Penyalur</th>
                             <th class="text-center"> Lokasi Lembaga Penyalur</th>
                             <th class="text-center"> Upload SKU</th>
                             <th class="text-center"> Upload Mesin/Tempat Usaha</th>
                             <th class="text-center"> Upload Surat Pengajuan</th>
                             <th class="text-center"> Upload Rekomendasi Lama</th>
                             <!-- Tombol Action -->
                             <th class="text-center">Action</th>

                         </tr>

                         <!-- Menampilkan Data Ke Tabel -->
                         <?php $no=1; foreach($rekomendasi as $r) :?>
                         <tr>
                             <!-- Data Pegawai -->
                             <td><?php echo $no++ ?></td>
                             <td><?php echo $r-> no_surat?></td>
                             <td><?php echo $r-> nik?></td>
                             <td><?php echo $r-> nama_pemilik?></td>
                             <td><?php echo $r-> alamat?></td>
                             <td><?php echo $r-> telp?></td>
                             <td><?php echo $r-> konsumen?></td>
                             <td><?php echo $r-> nama_usaha?></td>
                             <td><?php echo $r-> jenis_usaha?></td>
                             <td><?php echo $r-> satuan_kebutuhan?></td>
                             <td><?php echo $r-> tgl_pengajuan?></td>
                             <td><?php echo $r-> lembaga_penyalur_tempat_pengambilan?></td>
                             <td><?php echo $r-> jenis_alat?></td>
                             <td><?php echo $r-> jumlah_alat?></td>
                             <td><?php echo $r-> fungsi_alat?></td>
                             <td><?php echo $r-> jenis_bbm?></td>
                             <td><?php echo $r-> kebutuhan_bbm?></td>
                             <td><?php echo $r-> operasi?></td>
                             <td><?php echo $r-> konsumsi?></td>
                             <td><?php echo $r-> durasi_konsumsi?></td>
                             <td><?php echo $r-> jumlah_alokasi?></td>
                             <td><?php echo $r-> durasi_alokasi?></td>
                             <td><?php echo $r-> masa_berlaku?></td>
                             <td><?php echo $r-> no_lembaga_penyalur?></td>
                             <td><?php echo $r-> lok_lembaga_penyalur?></td>
                             <td><img src="<?php echo base_url().'assets/photo/'.$r->upload_sku ?>" width="75px"></td>
                             <td><img src="<?php echo base_url().'assets/photo/'.$r->up_mesin_tempat ?>" width="75px">
                             </td>
                             <td><img src="<?php echo base_url().'assets/photo/'.$r->up_surat_pengajuan ?>"
                                     width="75px"></td>
                             <td><img src="<?php echo base_url().'assets/photo/'.$r->up_rekom_lama?>" width="75px"></td>


                             <!-- Tombol Update dan Edit Data-->
                             <td>
                                 <div class="btn-group">
                                     <!-- Update Data -->
                                     <a class="btn btn-sm btn-primary"
                                         href="<?php echo base_url('administrator/rekom_solar/update_data_solar/'.$r->id_rekomendasi)?>">
                                         <i class="fas fa-edit"></i>
                                     </a>
                                     <!-- Delete Data -->
                                     <a onclick="return confirm('Apakah Anda Ingin Menghapusnya??')"
                                         class="btn btn-sm btn-danger"
                                         href="<?php echo base_url('administrator/rekom_solar/delete_data_aksi/' . $r->id_rekomendasi) ?>">
                                         <i class="fas fa-trash"></i>
                                     </a>
                                     <a class="btn btn-sm btn-primary" href="">
                                         <i class="fas fa-print"></i>
                                     </a>
                                     <a class="btn btn-sm btn-primary" href="">
                                         <i class="fas fa-info"></i>
                                     </a>
                                 </div>
                                 <style>
                                 .btn-group {
                                     display: flex;
                                     align-items: center;
                                     justify-content: center;
                                 }

                                 .btn-group .btn {
                                     margin-right: 5px;
                                 }
                                 </style>

                             </td>
                         </tr>
                         <?php endforeach; ?>
                     </table>
                 </div>
     </div>
     <!-- /.container-fluid -->