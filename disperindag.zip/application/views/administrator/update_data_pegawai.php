<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800"><?php echo $title ?>
        </h1>
    </div>

    <div class="card" style="width: 60%">
        <div class="card-body">
            <!-- FORM INPUT DATA -->
            <?php foreach ($daftar_pangkat as $d) : ?>
                <form method="POST" action="<?php echo base_url('administrator/daftar_urut_kepangkatan/update_data_aksi') ?>">
                    <div class="form-group">
                        <label>NIP</label>
                        <input type="hidden" name="id_pegawai" class="form-control" value="<?php echo $d->id_pegawai ?>">
                        <input type="text" name="nip" class="form-control" value="<?php echo $d->nip ?>">
                        <?php echo form_error('nip', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" name="nama" class="form-control" value="<?php echo $d->nama ?>">
                        <?php echo form_error('nama', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Pangkat/Golongan Ruang</label>
                        <select name="pangkat_gol_ruang" class="form-control">
                            <option value="" style="display:none;">Pilih Pangkat/Golongan Ruang</option>
                            <option value="Juru Muda I/A" <?php echo ($d->pangkat_gol_ruang == 'Juru Muda I/A') ? 'selected' : ''; ?>>Juru Muda I/A</option>
                            <option value="Juru Muda Tk I I/B" <?php echo ($d->pangkat_gol_ruang == 'Juru Muda Tk I I/B') ? 'selected' : ''; ?>>Juru Muda Tk I I/B</option>
                            <option value="Juru I/C" <?php echo ($d->pangkat_gol_ruang == 'Juru I/C') ? 'selected' : ''; ?>>Juru I/C</option>
                            <option value="Juru Tk I I/D" <?php echo ($d->pangkat_gol_ruang == 'Juru Tk I I/D') ? 'selected' : ''; ?>>Juru Tk I I/D</option>
                            <option value="Pengatur Muda II/A" <?php echo ($d->pangkat_gol_ruang == 'Pengatur Muda Tk I II/B') ? 'selected' : ''; ?>>Pengatur Muda II/A</option>
                            <option value="Pengatur Muda Tk I II/B" <?php echo ($d->pangkat_gol_ruang == 'Pengatur Muda Tk I II/B') ? 'selected' : ''; ?>>Pengatur Muda Tk I II/B</option>
                            <option value="Pengatur  II/C" <?php echo ($d->pangkat_gol_ruang == 'Pengatur  II/C') ? 'selected' : ''; ?>>Pengatur II/C</option>
                            <option value="Pengatur Tk I, II/d" <?php echo ($d->pangkat_gol_ruang == 'Pengatur Tk I, II/d') ? 'selected' : ''; ?>>Pengatur Tk I, II/d</option>
                            <option value="Penata Tk I II/D" <?php echo ($d->pangkat_gol_ruang == 'Penata Tk I II/D') ? 'selected' : ''; ?>>Penata Tk I II/D</option>
                            <option value="Penata Muda III/A" <?php echo ($d->pangkat_gol_ruang == 'Penata Muda III/A<') ? 'selected' : ''; ?>>Penata Muda III/A</option>
                            <option value="Penata III/C" <?php echo ($d->pangkat_gol_ruang == 'Penata III/C') ? 'selected' : ''; ?>>Penata III/C</option>
                            <option value="Penata Muda Tk I III/D" <?php echo ($d->pangkat_gol_ruang == 'Penata Muda Tk I III/D') ? 'selected' : ''; ?>>Penata Muda Tk I III/D</option>
                            <option value="Pembina IV/A" <?php echo ($d->pangkat_gol_ruang == 'Pembina IV/A') ? 'selected' : ''; ?>>Pembina IV/A</option>
                            <option value="Pembina Tk I IV/B" <?php echo ($d->pangkat_gol_ruang == 'Pembina Tk I IV/B') ? 'selected' : ''; ?>>Pembina Tk I IV/B</option>
                            <option value="Pembina utama muda IV/C" <?php echo ($d->pangkat_gol_ruang == 'Pembina utama muda IV/C') ? 'selected' : ''; ?>>Pembina utama muda IV/C</option>
                            <option value="Pembina utama madya IV/D" <?php echo ($d->pangkat_gol_ruang == 'Pembina utama madya IV/D') ? 'selected' : ''; ?>>Pembina utama madya IV/D</option>
                            <option value="Pembina utama IV/E" <?php echo ($d->pangkat_gol_ruang == 'Pembina utama IV/E') ? 'selected' : ''; ?>>Pembina utama IV/E</option>
                        </select>
                        <?php echo form_error('pangkat_gol_ruang', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Jabatan</label>
                        <select name="jabatan" class="form-control">
                            <option value="" style="display:none;">Pilih Jabatan Dinas</option>
                            <option value="Kepala Dinas" <?php echo ($d->jabatan == 'Kepala Dinas') ? 'selected' : ''; ?>>Kepala Dinas</option>
                            <option value="Sekretaris" <?php echo ($d->jabatan == 'Sekretaris') ? 'selected' : ''; ?>>Sekretaris</option>
                            <option value="Kepala Bidang Pembangunan Sumber Daya Industri" <?php echo ($d->jabatan == 'Kepala Bidang Pembangunan Sumber Daya Industri') ? 'selected' : ''; ?>>Kepala Bidang Pembangunan Sumber Daya Industri</option>
                            <option value="Kepala Bidang Sarana Dan Prasarana Pemberdayaan Industri" <?php echo ($d->jabatan == 'Kepala Bidang Sarana Dan Prasarana Pemberdayaan Industri') ? 'selected' : ''; ?>>Kepala Bidang Sarana Dan Prasarana Pemberdayaan Industri</option>
                            <option value="Kepala Bidang Perdagangan" <?php echo ($d->jabatan == 'Kepala Bidang Perdagangan') ? 'selected' : ''; ?>>Kepala Bidang Perdagangan</option>
                            <option value="Kepala Bidang Pengembangan Promosi Dan Perdagangan" <?php echo ($d->jabatan == 'Kepala Bidang Pengembangan Promosi Dan Perdagangan') ? 'selected' : ''; ?>>Kepala Bidang Pengembangan Promosi Dan Perdagangan</option>
                            <option value="Kepala Bidang Pasar" <?php echo ($d->jabatan == 'Kepala Bidang Pasar') ? 'selected' : ''; ?>>Kepala Bidang Pasar</option>
                            <option value="Kepala Sub Bagian Umum Dan Kepegawaian" <?php echo ($d->jabatan == 'Kepala Sub Bagian Umum Dan Kepegawaian') ? 'selected' : ''; ?>>Kepala Sub Bagian Umum Dan Kepegawaian</option>
                            <option value="Kepala Sub Bagian Keuangan Dan BMD" <?php echo ($d->jabatan == 'Kepala Sub Bagian Keuangan Dan BMD<') ? 'selected' : ''; ?>>Kepala Sub Bagian Keuangan Dan BMD</option>
                            <option value="Perencana Ahli Muda" <?php echo ($d->jabatan == 'Perencana Ahli Muda') ? 'selected' : ''; ?>>Perencana Ahli Muda</option>
                            <option value="Pengawas Kemotrologian" <?php echo ($d->jabatan == 'Pengawas Kemotrologian') ? 'selected' : ''; ?>>Pengawas Kemotrologian</option>
                            <option value="Analis Perdagangan Ahli Muda" <?php echo ($d->jabatan == 'Analis Perdagangan Ahli Muda') ? 'selected' : ''; ?>>Analis Perdagangan Ahli Muda</option>
                            <option value="Pengawas Perdagangan Ahli Muda" <?php echo ($d->jabatan == 'Pengawas Perdagangan Ahli Muda') ? 'selected' : ''; ?>>Pengawas Perdagangan Ahli Muda</option>
                            <option value="Kepala UPT Disperindag ESDM Wil V" <?php echo ($d->jabatan == 'Kepala UPT Disperindag ESDM Wil V') ? 'selected' : ''; ?>>Kepala UPT Disperindag ESDM Wil V</option>
                            <option value="Ka. Subbag TU UPT Disperindag ESDM Wil IV" <?php echo ($d->jabatan == 'Ka. Subbag TU UPT Disperindag ESDM Wil IV') ? 'selected' : ''; ?>>Ka. Subbag TU UPT Disperindag ESDM Wil IV</option>
                            <option value="Bendahara Pengeluaran Pembantu" <?php echo ($d->jabatan == 'Bendahara Pengeluaran Pembantu') ? 'selected' : ''; ?>>Bendahara Pengeluaran Pembantu</option>
                            <option value="Penyuluh Perindag Utama" <?php echo ($d->jabatan == 'Penyuluh Perindag Utama') ? 'selected' : ''; ?>>Penyuluh Perindag Utama</option>
                            <option value="Verifikator Anggaran" <?php echo ($d->jabatan == 'Verifikator Anggaran') ? 'selected' : ''; ?>>Verifikator Anggaran</option>
                            <option value="Juru Pungut Retribusi" <?php echo ($d->jabatan == 'Juru Pungut Retribusi') ? 'selected' : ''; ?>>Juru Pungut Retribusi</option>
                            <option value="Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk" <?php echo ($d->jabatan == 'Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk') ? 'selected' : ''; ?>>Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk</option>
                            <option value="Pengelola Kepegawaian" <?php echo ($d->jabatan == 'Pengelola Kepegawaian') ? 'selected' : ''; ?>>Pengelola Kepegawaian</option>
                            <option value="Pengelola Pameran Dan Peragaan Pd Seksi Perdagangan" <?php echo ($d->jabatan == 'Pengelola Pameran Dan Peragaan Pd Seksi Perdagangan') ? 'selected' : ''; ?>>Pengelola Pameran Dan Peragaan Pd Seksi Perdagangan</option>
                            <option value="Penyusun Rencana Kegiatan & Anggaran Pd Sub BAgian PEP" <?php echo ($d->jabatan == 'Penyusun Rencana Kegiatan & Anggaran Pd Sub BAgian PEP') ? 'selected' : ''; ?>>Penyusun Rencana Kegiatan & Anggaran Pd Sub BAgian PEP</option>
                            <option value="Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk" <?php echo ($d->jabatan == 'Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk') ? 'selected' : ''; ?>>Pengadministrasi Identifikasi Dan Evaluasi Sentra Pengolahan Produk</option>
                            <option value="Pengelola Keuangan Pd Sub Bagian Keuangan Dan BMD" <?php echo ($d->jabatan == 'Pengelola Keuangan Pd Sub Bagian Keuangan Dan BMD') ? 'selected' : ''; ?>>Pengelola Keuangan Pd Sub Bagian Keuangan Dan BMD</option>
                            <option value="Pengolah Data" <?php echo ($d->jabatan == 'Pengolah Data') ? 'selected' : ''; ?>>Pengolah Data</option>
                            <option value="Pengurus Aset Barang Milik Daerah" <?php echo ($d->jabatan == 'Pengurus Aset Barang Milik Daerah') ? 'selected' : ''; ?>>Pengurus Aset Barang Milik Daerah</option>
                            <option value="Pengelola Keuangan" <?php echo ($d->jabatan == 'Pengelola Keuangan') ? 'selected' : ''; ?>>Pengelola Keuangan</option>
                            <option value="Analis Perdagangan Ahli Muda" <?php echo ($d->jabatan == 'Penata Laporan Keuangan') ? 'selected' : ''; ?>>Penata Laporan Keuangan</option>
                            <option value="Ahli Pertama Pranata Komputer" <?php echo ($d->jabatan == 'Ahli Pertama Pranata Komputer') ? 'selected' : ''; ?>>Ahli Pertama Pranata Komputer</option>
                            <option value="Analis Industri" <?php echo ($d->jabatan == 'Analis Industri') ? 'selected' : ''; ?>>Analis Industri</option>
                            <option value="Penyusun Rencana Kebutuhan Rumahh Tangga Dan Perlengkapan" <?php echo ($d->jabatan == 'Penyusun Rencana Kebutuhan Rumahh Tangga Dan Perlengkapan') ? 'selected' : ''; ?>>Penyusun Rencana Kebutuhan Rumahh Tangga Dan Perlengkapan</option>
                            <option value="Kepala Sub Bagian Tata Usaha UPT Wilayah XIV" <?php echo ($d->jabatan == 'Kepala Sub Bagian Tata Usaha UPT Wilayah XIV') ? 'selected' : ''; ?>>Kepala Sub Bagian Tata Usaha UPT Wilayah XIV</option>
                            <option value="Juru Pungut Retribusi" <?php echo ($d->jabatan == 'Juru Pungut Retribusi pada UPT Kec. Wanaraja') ? 'selected' : ''; ?>>Juru Pungut Retribusi pada UPT Kec. Wanaraja</option>
                            <option value="Penera" <?php echo ($d->jabatan == 'Penera') ? 'selected' : ''; ?>>Penera</option>
                            <option value="Pengadministrasi Karcis" <?php echo ($d->jabatan == 'Pengadministrasi Karcis') ? 'selected' : ''; ?>>Pengadministrasi Karcis</option>
                            <option value="Bendahara Pengeluaran" <?php echo ($d->jabatan == 'Bendahara Pengeluaran') ? 'selected' : ''; ?>>Bendahara Pengeluaran</option>
                            <option value="Analis Industri Logam Mesin Elektronik Dan Bahan Bangunan" <?php echo ($d->jabatan == 'Analis Industri Logam Mesin Elektronik Dan Bahan Bangunan') ? 'selected' : ''; ?>>Analis Industri Logam Mesin Elektronik Dan Bahan Bangunan</option>
                            <option value="Pelaksana" <?php echo ($d->jabatan == 'Pelaksana') ? 'selected' : ''; ?>>Pelaksana</option>
                        </select>
                        <?php echo form_error('jabatan', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Eselon</label>
                        <select name="eselon" class="form-control">
                            <option value="" style="display:none;">Pilih Eselon</option>
                            <option value="II.a" <?php echo ($d->eselon == 'II.a') ? 'selected' : ''; ?>>II.a</option>
                            <option value="II.b" <?php echo ($d->eselon == 'II.b') ? 'selected' : ''; ?>>II.b</option>
                            <option value="III.a" <?php echo ($d->eselon == 'III.a') ? 'selected' : ''; ?>>III.a</option>
                            <option value="III.b" <?php echo ($d->eselon == 'III.b') ? 'selected' : ''; ?>>III.b</option>
                            <option value="IV.a" <?php echo ($d->eselon == 'IV.a') ? 'selected' : ''; ?>>IV.a</option>
                            <option value="IV.b" <?php echo ($d->eselon == 'IV.b') ? 'selected' : ''; ?>>IV.b</option>
                        </select>
                        <?php echo form_error('eselon', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Unit Bidang</label>
                        <select name="unit_bidang" class="form-control">
                            <option value="" style="display:none;">Pilih Unit Bidang</option>
                            <option value="Kepala Subbagian Perencanaan, Evaluasi Dan Pelaporan" <?php echo ($d->unit_bidang == 'Kepala Subbagian Perencanaan, Evaluasi Dan Pelaporan') ? 'selected' : ''; ?>>Kepala Subbagian Perencanaan, Evaluasi Dan Pelaporan</option>
                            <option value="Kepala Subbagian Umum Dan Kepegawaian" <?php echo ($d->unit_bidang == 'Kepala Subbagian Umum Dan Kepegawaian') ? 'selected' : ''; ?>>Kepala Subbagian Umum Dan Kepegawaian</option>
                            <option value="Kepala Subbagian Keuangan Dan BMD" <?php echo ($d->unit_bidang == 'Kepala Subbagian Keuangan Dan BMD') ? 'selected' : ''; ?>>Kepala Subbagian Keuangan Dan BMD</option>
                            <option value="Kepala Seksi Industri Pangan" <?php echo ($d->unit_bidang == 'Kepala Seksi Industri Pangan') ? 'selected' : ''; ?>>Kepala Seksi Industri Pangan</option>
                            <option value="Kepala Seksi Industri Hasil Pertanian" <?php echo ($d->unit_bidang == 'Kepala Seksi Industri Hasil Pertanian') ? 'selected' : ''; ?>>Kepala Seksi Industri Hasil Pertanian</option>
                            <option value="Kepala Seksi Hasil Hutan Dan Hasil Laut" <?php echo ($d->unit_bidang == 'Kepala Seksi Hasil Hutan Dan Hasil Laut') ? 'selected' : ''; ?>>Kepala Seksi Hasil Hutan Dan Hasil Laut</option>
                            <option value="Kepala Seksi Indutri Tekstil, Kulit, Kimia, Alas Kaki Dan Aneka" <?php echo ($d->unit_bidang == 'Kepala Seksi Indutri Tekstil, Kulit, Kimia, Alas Kaki Dan Aneka') ? 'selected' : ''; ?>>Kepala Seksi Indutri Tekstil, Kulit, Kimia, Alas Kaki Dan Aneka</option>
                            <option value="Kepala Seksi Industri Logam, Mesin, Elektronika Dan Bahan Bangunan" <?php echo ($d->unit_bidang == 'Kepala Seksi Industri Logam, Mesin, Elektronika Dan Bahan Bangunan') ? 'selected' : ''; ?>>Kepala Seksi Industri Logam, Mesin, Elektronika Dan Bahan Bangunan</option>
                            <option value="Kepala Seksi Pemanfaatan Energi Sumberdaya Mineral" <?php echo ($d->unit_bidang == 'Kepala Seksi Pemanfaatan Energi Sumberdaya Mineral') ? 'selected' : ''; ?>>Kepala Seksi Pemanfaatan Energi Sumberdaya Mineral</option>
                            <option value="Kepala Seksi Pengadaan Dan Penyaluran" <?php echo ($d->unit_bidang == 'Kepala Seksi Pengadaan Dan Penyaluran') ? 'selected' : ''; ?>>Kepala Seksi Pengadaan Dan Penyaluran</option>
                            <option value="Kepala Seksi Sarana Dan Prasarana" <?php echo ($d->unit_bidang == 'Kepala Seksi Sarana Dan Prasarana') ? 'selected' : ''; ?>>Kepala Seksi Sarana Dan Prasarana</option>
                            <option value="Kepala Seksi Kemotrologian" <?php echo ($d->unit_bidang == 'Kepala Seksi Kemotrologian') ? 'selected' : ''; ?>>Kepala Seksi Kemotrologian</option>
                            <option value="Kepala Seksi Promosi Perdagangan" <?php echo ($d->unit_bidang == 'Kepala Seksi Promosi Perdagangan') ? 'selected' : ''; ?>>Kepala Seksi Promosi Perdagangan</option>
                            <option value="Kepala Seksi Bina Usaha" <?php echo ($d->unit_bidang == 'Kepala Seksi Bina Usaha') ? 'selected' : ''; ?>>Kepala Seksi Bina Usaha</option>
                            <option value="Kepala Seksi Kelembagaan Usaha" <?php echo ($d->unit_bidang == 'Kepala Seksi Kelembagaan Usaha') ? 'selected' : ''; ?>>Kepala Seksi Kelembagaan Usaha</option>
                            <option value="Kepala Seksi Pengelolaan Pendapatan" <?php echo ($d->unit_bidang == 'Kepala Seksi Pengelolaan Pendapatan') ? 'selected' : ''; ?>>Kepala Seksi Pengelolaan Pendapatan</option>
                            <option value="Kepala Seksi Pengembangan Dan Tata Kelola Pasar" <?php echo ($d->unit_bidang == 'Kepala Seksi Pengembangan Dan Tata Kelola Pasar') ? 'selected' : ''; ?>>Kepala Seksi Pengembangan Dan Tata Kelola Pasar</option>
                            <option value="Kepala Seksi Kebersihan, Keamanan, Dan Ketertiban" <?php echo ($d->unit_bidang == 'Kepala Seksi Kebersihan, Keamanan, Dan Ketertiban') ? 'selected' : ''; ?>>Kepala Seksi Kebersihan, Keamanan, Dan Ketertiban</option>
                            <option value="Kepala UPT Cikajang" <?php echo ($d->unit_bidang == 'Kepala UPT Cikajang') ? 'selected' : ''; ?>>Kepala UPT Cikajang</option>
                            <option value="Kepala UPT Bayongbong" <?php echo ($d->unit_bidang == 'Kepala UPT Bayongbong') ? 'selected' : ''; ?>>Kepala UPT Bayongbong</option>
                            <option value="Kepala UPT Cisurupan" <?php echo ($d->unit_bidang == 'epala UPT Cisurupan') ? 'selected' : ''; ?>>Kepala UPT Cisurupan</option>
                            <option value="Kepala UPT Limbangan" <?php echo ($d->unit_bidang == 'Kepala UPT Limbangan') ? 'selected' : ''; ?>>Kepala UPT Limbangan</option>
                            <option value="Kepala UPT Samarang" <?php echo ($d->unit_bidang == 'Kepala UPT Samarang') ? 'selected' : ''; ?>>Kepala UPT Samarang</option>
                            <option value="Kepala UPT Singajaya" <?php echo ($d->unit_bidang == 'Kepala UPT Singajaya') ? 'selected' : ''; ?>>Kepala UPT Singajaya</option>
                            <option value="Kepala UPT Leles" <?php echo ($d->unit_bidang == 'Kepala UPT Leles') ? 'selected' : ''; ?>>Kepala UPT Leles</option>
                            <option value="Kepala UPT Pameungpeuk" <?php echo ($d->unit_bidang == 'Kepala UPT Pameungpeuk') ? 'selected' : ''; ?>>Kepala UPT Pameungpeuk</option>
                            <option value="Kepala UPT Wanaraja" <?php echo ($d->unit_bidang == 'Kepala UPT Wanaraja') ? 'selected' : ''; ?>>Kepala UPT Wanaraja</option>
                            <option value="Kepala UPT Malangbong" <?php echo ($d->unit_bidang == 'Kepala UPT Malangbong') ? 'selected' : ''; ?>>Kepala UPT Malangbong</option>
                            <option value="Kepala UPT Cibatu" <?php echo ($d->unit_bidang == 'Kepala UPT Cibatu') ? 'selected' : ''; ?>>Kepala UPT Cibatu</option>
                            <option value="Kepala UPT Kadungora" <?php echo ($d->unit_bidang == 'Kepala UPT Kadungora') ? 'selected' : ''; ?>>Kepala UPT Kadungora</option>
                            <option value="Kepala UPT Bungbulang" <?php echo ($d->unit_bidang == 'Kepala UPT Bungbulang') ? 'selected' : ''; ?>>Kepala UPT Bungbulang</option>
                            <option value="Kepala UPT Garut Kota" <?php echo ($d->unit_bidang == 'Kepala UPT Garut Kota') ? 'selected' : ''; ?>>Kepala UPT Garut Kota</option>
                            <option value="Kepala UPT Banyuresmi" <?php echo ($d->unit_bidang == 'Kepala UPT Banyuresmi') ? 'selected' : ''; ?>>Kepala UPT Banyuresmi</option>
                            <option value="Kepala UPT Banyuresmi" <?php echo ($d->unit_bidang == 'Kepala UPT Karangpawitan') ? 'selected' : ''; ?>>Kepala UPT Karangpawitan</option>
                            <option value="Kepala UPT Sukawening" <?php echo ($d->unit_bidang == 'Kepala UPT Sukawening') ? 'selected' : ''; ?>>Kepala UPT Sukawening</option>
                            <option value="Kepala UPT Cilawu" <?php echo ($d->unit_bidang == 'Kepala UPT Cilawu') ? 'selected' : ''; ?>>Kepala UPT Cilawu</option>
                            <option value="Kepala UPT Tarogong Kidul" <?php echo ($d->unit_bidang == 'Kepala UPT Tarogong Kidul') ? 'selected' : ''; ?>>Kepala UPT Tarogong Kidul</option>
                            <option value="Kepala UPT Cisewu" <?php echo ($d->unit_bidang == 'Kepala UPT Cisewu') ? 'selected' : ''; ?>>Kepala UPT Cisewu</option>
                            <option value="Kepala UPT Fungsional Tertentu" <?php echo ($d->unit_bidang == 'Kepala UPT Fungsional Tertentu') ? 'selected' : ''; ?>>Kepala UPT Fungsional Tertentu</option>
                        </select>
                        <?php echo form_error('unit_bidang', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Bidang</label>
                        <select name="bidang" class="form-control">
                            <option value="" style="display:none;">Pilih Bidang</option>
                            <option value="Sekretariat" <?php echo ($d->bidang == 'Sekretariat') ? 'selected' : ''; ?>>Sekretariat</option>
                            <option value="Bidang Industri Agro" <?php echo ($d->bidang == 'Bidang Industri Agro') ? 'selected' : ''; ?>>Bidang Industri Agro</option>
                            <option value="Bidang Non Agro Dan ESDM" <?php echo ($d->bidang == 'Bidang Non Agro Dan ESDM') ? 'selected' : ''; ?>>Bidang Non Agro Dan ESDM</option>
                            <option value="Bidang Pengembangan Usaha Perdagangan" <?php echo ($d->bidang == 'Bidang Pengembangan Usaha Perdagangan') ? 'selected' : ''; ?>>Bidang Pengembangan Usaha Perdagangan</option>
                            <option value="Bidang Pengelolaan Pasar" <?php echo ($d->bidang == 'Bidang Pengelolaan Pasar') ? 'selected' : ''; ?>>Bidang Pengelolaan Pasar</option>
                            <option value="UPT" <?php echo ($d->bidang == 'UPT') ? 'selected' : ''; ?>>UPT</option>
                            <option value="Fungsional Tertentu" <?php echo ($d->bidang == 'Fungsional Tertentu') ? 'selected' : ''; ?>>Fungsional Tertentu</option>
                        </select>
                        <?php echo form_error('bidang', '<div class="text-small text-danger"></div>'); ?>
                    </div>


                    <div class="form-group">
                        <label>No Karpeg</label>
                        <input type="text" name="no_karpeg" class="form-control" value="<?php echo $d->no_karpeg ?>">
                        <?php echo form_error('no_karpeg', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>No Seri Kepegawaian</label>
                        <input type="text" name="nomor_seri_kepegawaian" class="form-control" value="<?php echo $d->nomor_seri_kepegawaian ?>">
                        <?php echo form_error('nomor_seri_kepagawaian', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Golongan Gaji</label>
                        <input type="text" name="golongan_gaji" class="form-control" value="<?php echo $d->golongan_gaji ?>">
                        <?php echo form_error('golongan_gaji', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Jabatan Dinas</label>
                        <select name="jabatan_dinas" class="form-control">
                            <option value="">Pilih Jabatan Dinas</option>
                            <option value="Pengguna Anggaran" <?php echo ($d->jabatan_dinas == 'Pengguna Anggaran') ? 'selected' : ''; ?>>Pengguna Anggaran</option>
                            <option value="Kuasa Pengguna Anggaran" <?php echo ($d->jabatan_dinas == 'Kuasa Pengguna Anggaran') ? 'selected' : ''; ?>>Kuasa Pengguna Anggaran</option>
                            <option value="Pejabat Pelaksana Teknis Kegiatan" <?php echo ($d->jabatan_dinas == 'Pejabat Pelaksana Teknis Kegiatan') ? 'selected' : ''; ?>>Pejabat Pelaksana Teknis Kegiatan</option>
                            <option value="Bendahara Pengeluaran" <?php echo ($d->jabatan_dinas == 'Bendahara Pengeluaran') ? 'selected' : ''; ?>>Bendahara Pengeluaran</option>
                            <option value="Pembuat Daftar Gaji" <?php echo ($d->jabatan_dinas == 'Pembuat Daftar Gaji') ? 'selected' : ''; ?>>Pembuat Daftar Gaji</option>
                            <option value="Bendahara Pengeluaran Pembantu" <?php echo ($d->jabatan_dinas == 'Bendahara Pengeluaran Pembantu') ? 'selected' : ''; ?>>Bendahara Pengeluaran Pembantu</option>
                            <option value="Penera Madya" <?php echo ($d->jabatan_dinas == 'Penera Madya') ? 'selected' : ''; ?>>Penera Madya</option>
                            <option value="Sekretaris" <?php echo ($d->jabatan_dinas == 'Sekretaris') ? 'selected' : ''; ?>>Sekretaris</option>
                        </select>
                        <?php echo form_error('jabatan_dinas', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Golongan Awal</label>
                        <select name="gol_awal" class="form-control">
                            <option value="" style="display:none;">Pilih Golongan Awal</option>
                            <option value="Juru Muda I/A" <?php echo ($d->gol_awal == 'Juru Muda I/A') ? 'selected' : ''; ?>>Juru Muda I/A</option>
                            <option value="Juru Muda Tk I I/B" <?php echo ($d->gol_awal == 'Juru Muda Tk I I/B') ? 'selected' : ''; ?>>Juru Muda Tk I I/B</option>
                            <option value="Juru I/C" <?php echo ($d->gol_awal == 'Juru I/C') ? 'selected' : ''; ?>>Juru I/C</option>
                            <option value="Juru Tk I I/D" <?php echo ($d->gol_awal == 'Juru Tk I I/D') ? 'selected' : ''; ?>>Juru Tk I I/D</option>
                            <option value="Pengatur Muda II/A" <?php echo ($d->gol_awal == 'Pengatur Muda II/A') ? 'selected' : ''; ?>>Pengatur Muda II/A</option>
                            <option value="Pengatur Muda Tk I II/B" <?php echo ($d->gol_awal == 'Pengatur Muda Tk I II/B') ? 'selected' : ''; ?>>Pengatur Muda Tk I II/B</option>
                            <option value="Pengatur  II/C" <?php echo ($d->gol_awal == 'Pengatur  II/C') ? 'selected' : ''; ?>>Pengatur II/C</option>
                            <option value="Pengatur Tk I, II/d" <?php echo ($d->gol_awal == 'Pengatur Tk I, II/d') ? 'selected' : ''; ?>>Pengatur Tk I, II/d</option>
                            <option value="Penata Tk I II/D" <?php echo ($d->gol_awal == 'Penata Tk I II/D') ? 'selected' : ''; ?>>Penata Tk I II/D</option>
                            <option value="Penata Muda III/A" <?php echo ($d->gol_awal == 'Penata Muda III/A') ? 'selected' : ''; ?>>Penata Muda III/A</option>
                            <option value="Penata III/C" <?php echo ($d->gol_awal == 'Penata III/C') ? 'selected' : ''; ?>>Penata III/C</option>
                            <option value="Penata Muda Tk I III/D" <?php echo ($d->gol_awal == 'Penata Muda Tk I III/D') ? 'selected' : ''; ?>>Penata Muda Tk I III/D</option>
                            <option value="Pembina IV/A" <?php echo ($d->gol_awal == 'Pembina IV/A') ? 'selected' : ''; ?>>Pembina IV/A</option>
                            <option value="Pembina Tk I IV/B" <?php echo ($d->gol_awal == 'Pembina Tk I IV/B') ? 'selected' : ''; ?>>Pembina Tk I IV/B</option>
                            <option value="Pembina utama muda IV/C" <?php echo ($d->gol_awal == 'Pembina utama muda IV/C') ? 'selected' : ''; ?>>Pembina utama muda IV/C</option>
                            <option value="Pembina utama madya IV/D" <?php echo ($d->gol_awal == 'Pembina utama madya IV/D') ? 'selected' : ''; ?>>Pembina utama madya IV/D</option>
                            <option value="Pembina utama IV/E" <?php echo ($d->gol_awal == 'Pembina utama IV/E') ? 'selected' : ''; ?>>Pembina utama IV/E</option>
                        </select>
                        <?php echo form_error('gol_awal', '<div class="text-small text-danger"></div>'); ?>
                    </div>


                    <div class="form-group">
                        <label>TMT Awal</label>
                        <input type="date" name="tmt_awal" class="form-control" value="<?php echo $d->tmt_awal ?>">
                        <?php echo form_error('tmt_awal', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Golongan Akhir</label>
                        <select name="gol_akhir" class="form-control">
                            <option value="" style="display:none;">Pilih Golongan Akhir</option>
                            <option value="Juru Muda I/A" <?php echo ($d->gol_akhir == 'Juru Muda I/A') ? 'selected' : ''; ?>>Juru Muda I/A</option>
                            <option value="Juru Muda Tk I I/B" <?php echo ($d->gol_akhir == 'Juru Muda Tk I I/B') ? 'selected' : ''; ?>>Juru Muda Tk I I/B</option>
                            <option value="Juru I/C" <?php echo ($d->gol_akhir == 'Juru I/C') ? 'selected' : ''; ?>>Juru I/C</option>
                            <option value="Juru Tk I I/D" <?php echo ($d->gol_akhir == 'Juru Tk I I/D') ? 'selected' : ''; ?>>Juru Tk I I/D</option>
                            <option value="Pengatur Muda II/A" <?php echo ($d->gol_akhir == 'Pengatur Muda II/A') ? 'selected' : ''; ?>>Pengatur Muda II/A</option>
                            <option value="Pengatur Muda Tk I II/B" <?php echo ($d->gol_akhir == 'Pengatur Muda Tk I II/B') ? 'selected' : ''; ?>>Pengatur Muda Tk I II/B</option>
                            <option value="Pengatur  II/C" <?php echo ($d->gol_akhir == 'Pengatur  II/C') ? 'selected' : ''; ?>>Pengatur II/C</option>
                            <option value="Pengatur Tk I, II/d" <?php echo ($d->gol_akhir == 'Pengatur Tk I, II/d') ? 'selected' : ''; ?>>Pengatur Tk I, II/d</option>
                            <option value="Penata Tk I II/D" <?php echo ($d->gol_akhir == 'Penata Tk I II/D') ? 'selected' : ''; ?>>Penata Tk I II/D</option>
                            <option value="Penata Muda III/A" <?php echo ($d->gol_akhir == 'Penata Muda III/A') ? 'selected' : ''; ?>>Penata Muda III/A</option>
                            <option value="Penata III/C" <?php echo ($d->gol_akhir == 'Penata III/C') ? 'selected' : ''; ?>>Penata III/C</option>
                            <option value="Penata Muda Tk I III/D" <?php echo ($d->gol_akhir == 'Penata Muda Tk I III/D') ? 'selected' : ''; ?>>Penata Muda Tk I III/D</option>
                            <option value="Pembina IV/A" <?php echo ($d->gol_akhir == 'Pembina IV/A') ? 'selected' : ''; ?>>Pembina IV/A</option>
                            <option value="Pembina Tk I IV/B" <?php echo ($d->gol_akhir == 'Pembina Tk I IV/B') ? 'selected' : ''; ?>>Pembina Tk I IV/B</option>
                            <option value="Pembina utama muda IV/C" <?php echo ($d->gol_akhir == 'Pembina utama muda IV/C') ? 'selected' : ''; ?>>Pembina utama muda IV/C</option>
                            <option value="Pembina utama madya IV/D" <?php echo ($d->gol_akhir == 'Pembina utama madya IV/D') ? 'selected' : ''; ?>>Pembina utama madya IV/D</option>
                            <option value="Pembina utama IV/E" <?php echo ($d->gol_akhir == 'Pembina utama IV/E') ? 'selected' : ''; ?>>Pembina utama IV/E</option>
                        </select>
                        <?php echo form_error('gol_akhir', '<div class="text-small text-danger"></div>'); ?>
                    </div>


                    <div class="form-group">
                        <label>TMT Akhir</label>
                        <input type="date" name="tmt_akhir" class="form-control" value="<?php echo $d->tmt_akhir ?>">
                        <?php echo form_error('tmt_akhir', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>TMT Jabatan</label>
                        <input type="date" name="tmt_jabatan" class="form-control" value="<?php echo $d->tmt_jabatan ?>">
                        <?php echo form_error('tmt_jabatan', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Pendidikan</label>
                        <input type="text" name="pendidikan" class="form-control" value="<?php echo $d->pendidikan ?>">
                        <?php echo form_error('pendidikan', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Jurusan</label>
                        <input type="text" name="jurusan" class="form-control" value="<?php echo $d->pendidikan ?>">
                        <?php echo form_error('jurusan', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Sekolah</label>
                        <input type="text" name="sekolah" class="form-control" value="<?php echo $d->sekolah ?>">
                        <?php echo form_error('sekolah', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Lulus</label>
                        <input type="text" name="lulus" class="form-control" value="<?php echo $d->lulus ?>">
                        <?php echo form_error('lulus', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input type="text" name="tempat_lahir" class="form-control" value="<?php echo $d->tempat_lahir ?>">
                        <?php echo form_error('tempat_lahir', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Tanggal_lahir</label>
                        <input type="date" name="tanggal_lahir" class="form-control" value="<?php echo $d->tanggal_lahir ?>">
                        <?php echo form_error('tanggal_lahir', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select name="jenis_kelamin" class="form-control">
                            <option value="">Pilih Jenis Kelamin</option>
                            <option value="Laki-laki" <?php echo ($d->jenis_kelamin == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
                            <option value="Perempuan" <?php echo ($d->jenis_kelamin == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
                        </select>
                        <?php echo form_error('jenis_kelamin', '<div class="text-small text-danger"></div>'); ?>
                    </div>


                    <div class="form-group">
                        <label>Agama</label>
                        <select name="agama" class="form-control">
                            <option value="" style="display:none;">Pilih Agama</option>
                            <option value="Islam" <?php echo ($d->agama == 'Islam') ? 'selected' : ''; ?>>Islam</option>
                            <option value="Kristen" <?php echo ($d->agama == 'Kristen') ? 'selected' : ''; ?>>Kristen</option>
                            <option value="Hindu" <?php echo ($d->agama == 'Hindu') ? 'selected' : ''; ?>>Hindu</option>
                            <option value="Budha" <?php echo ($d->agama == 'Budha') ? 'selected' : ''; ?>>Budha</option>
                            <option value="Kongghucu" <?php echo ($d->agama == 'Kongghucu') ? 'selected' : ''; ?>>Kongghucu</option>
                        </select>
                        <?php echo form_error('agama', '<div class="text-small text-danger"></div>'); ?>
                    </div>


                    <div class="form-group">
                        <label>Status Perkawinan</label>
                        <input type="text" name="status_perkawinan" class="form-control" value="<?php echo $d->status_perkawinan ?>">
                        <?php echo form_error('status_perkawinan', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Jalan Kampung</label>
                        <input type="text" name="jalan_kampung" class="form-control" value="<?php echo $d->jalan_kampung ?>">
                        <?php echo form_error('jalan_kampung', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>RT</label>
                        <input type="text" name="rt" class="form-control" value="<?php echo $d->rt ?>">
                        <?php echo form_error('rt', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>RW</label>
                        <input type="text" name="rw" class="form-control" value="<?php echo $d->rw ?>">
                        <?php echo form_error('rw', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Kelurahan Desa</label>
                        <input type="text" name="kelurahan_desa" class="form-control" value="<?php echo $d->kelurahan_desa ?>">
                        <?php echo form_error('kelurahan_desa', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Kecamatan</label>
                        <input type="text" name="kecamatan" class="form-control" value="<?php echo $d->kecamatan ?>">
                        <?php echo form_error('kecamatan', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Kabupaten</label>
                        <input type="text" name="kabupaten" class="form-control" value="<?php echo $d->kabupaten ?>">
                        <?php echo form_error('kabupaten', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Kota</label>
                        <input type="text" name="kota" class="form-control" value="<?php echo $d->kota ?>">
                        <?php echo form_error('kota', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Telepon</label>
                        <input type="text" name="telepon" class="form-control" value="<?php echo $d->telepon ?>">
                        <?php echo form_error('telepon', '<div class="text-small text-danger"></div>'); ?>
                    </div>

                    <div class="form-group">
                        <label>Penghargaan</label>
                        <select name="penghargaan" class="form-control">
                            <option value="" style="display:none;">Pilih Penghargaan</option>
                            <option value="Penghargaan Bupati 10 Tahun" <?php echo ($d->penghargaan == 'Penghargaan Bupati 10 Tahun') ? 'selected' : ''; ?>>Penghargaan Bupati 10 Tahun</option>
                            <option value="Penghargaan Bupati 20 Tahun" <?php echo ($d->penghargaan == 'Penghargaan Bupati 20 Tahun') ? 'selected' : ''; ?>>Penghargaan Bupati 20 Tahun</option>
                            <option value="Penghargaan Bupati 30 Tahun" <?php echo ($d->penghargaan == 'Penghargaan Bupati 30 Tahun') ? 'selected' : ''; ?>>Penghargaan Bupati 30 Tahun</option>
                            <option value="Penghargaan Presiden 10 Tahun" <?php echo ($d->penghargaan == 'Penghargaan Presiden 10 Tahun') ? 'selected' : ''; ?>>Penghargaan Presiden 10 Tahun</option>
                            <option value="Penghargaan Presiden 20 Tahun" <?php echo ($d->penghargaan == 'Penghargaan Presiden 20 Tahun') ? 'selected' : ''; ?>>Penghargaan Presiden 20 Tahun</option>
                            <option value="Penghargaan Presiden 30 Tahun" <?php echo ($d->penghargaan == 'Penghargaan Presiden 30 Tahun') ? 'selected' : ''; ?>>Penghargaan Presiden 30 Tahun</option>

                        </select>
                        <?php echo form_error('penghargaan', '<div class="text-small text-danger"></div>'); ?>
                    </div>


                    <div class="form-group">
                        <label>Keterangan</label>
                        <input type="text" name="keterangan" class="form-control" value="<?php echo $d->keterangan ?>">
                        <?php echo form_error('keterangan', '<div class="text-small text-danger"></div>'); ?>
                    </div>


                    <button type="submit" class="btn btn-success">Update</button>

                </form>
            <?php endforeach; ?>
        </div>
    </div>

</div>