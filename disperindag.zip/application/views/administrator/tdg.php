       <!-- Begin Page Content -->
       <div class="container-fluid">

<!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo $title?></h1> 
        </div>
                        <a class="btn btn-sm mb-3 btn-success "
                        href="<?php echo base_url('administrator/tdg/tambah_tdg')?>">
                        <i class="fas fa-plus"> Tambah Data</i></a>
                        <?php echo $this->session->flashdata('pesan')?>     
                        <div class="table-responsive">          
    <table class="table table-bordered table-striped mt-2">
        <tr>

<style>
        .table-container {
            overflow-x: auto;
        }

        .table-container table {
            min-width: 100%;
        }
    </style>             
                        
       <table class="table table-bordered table-striped mt-2">
        
       <tr>
            <th class="text-center">No</th>
            <th class="text-center">Nama Pemilik</th>
            <th class="text-center">Alamat Pemilik</th>
            <th class="text-center">Nama Perusahaan</th>
            <th class="text-center">Alamat Perusahaan</th>
            <th class="text-center">Alamat Gudang</th>
            <th class="text-center">Telp/Fax</th>
            <th class="text-center">NIB</th>
            <th class="text-center">NPWP</th>
            <th class="text-center">E Mail</th>
            <th class="text-center">Investasi</th>
            <th class="text-center">Website</th>
            <th class="text-center">Titik Koordinat</th>
            <th class="text-center">Luas Lahan (M2)</th>
            <th class="text-center">Luas (M2)</th>
            <th class="text-center">Kapasitas (M3/TON)</th>
            <th class="text-center">Nomor & Tgl BAP</th>
            <th class="text-center">Nomor & Tgl Pertek</th>
            <th class="text-center">Nomor & Tgl Tdg</th>
            <th class="text-center">Komoditas Gudang</th>
            <th class="text-center">Action</th>
        </tr>
        <!-- membuat variabel untuk increment --> 
        <?php $no=1;
            //menampiljan data nya menggunakan looping for each 
            foreach($tdg as $t) : ?>
            <tr> 
                <!-- panggil variabel increment otomatis nya -->
                <td><?php echo $no++ ?></td>
                <td> <?php echo $t->nama_pemilik ?> </td>
                <td> <?php echo $t->alamat_pemilik ?> </td>
                <td> <?php echo $t->nama_perusahaan ?> </td>
                <td> <?php echo $t->alamat_perusahaan ?> </td>
                <td> <?php echo $t->alamat_gudang ?> </td>
                <td> <?php echo $t->telp_fax ?> </td>
                <td> <?php echo $t->nib ?> </td>
                <td> <?php echo $t->npwp ?> </td>
                <td> <?php echo $t->email ?> </td>
                <td> <?php echo $t->investasi ?> </td>
                <td> <?php echo $t->website ?> </td>
                <td> <?php echo $t->titik_koordinat ?> </td>
                <td> <?php echo $t->luas_lahan ?> </td>
                <td> <?php echo $t->luas ?> </td>
                <td> <?php echo $t->kapasitas ?> </td>
                <td> <?php echo $t->nomor_tgl_bap ?> </td>
                <td> <?php echo $t->nomor_tgl_pertek ?> </td>
                <td> <?php echo $t->nomor_tgl_tdg ?> </td>
                <td> <?php echo $t->komoditas_gudang ?> </td>
                
                <!-- Tombol Update dan Edit Data-->
                <td>
                <div class="btn-group">
                <!-- Update Data -->
                <a class="btn btn-sm btn-primary" href="<?php echo base_url('administrator/tdg/update_tdg/'.$t->id_tdg)?>">
                    <i class="fas fa-edit"></i>
                </a>
                <!-- Delete Data -->
                <a onclick="return confirm('Apakah Anda Ingin Menghapusnya??')" class="btn btn-sm btn-danger" href="<?php echo base_url('administrator/tdg/delete_data/'.$t->id_tdg)?>">
                    <i class="fas fa-trash"></i>
                </a>
                </div>
                <style>.btn-group {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    }

                    .btn-group .btn {
                        margin-right: 5px;
                    }
                </style>
                    
                </td>
            </tr>
        <?php endforeach; ?>
        </table>
        </div>
    </div>
