       <!-- Begin Page Content -->
       <div class="container-fluid">

<!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo $title?></h1> 
        </div>
                        <a class="btn btn-sm mb-3 btn-success "
                        href="<?php echo base_url('admin/dataJabatan/tambahData/')?>">
                        <i class="fas fa-plus"> Tambah Data</i></a>
                        <?php echo $this->session->flashdata('pesan')?>            
       <table class="table table-bordered table-striped mt-2">
        <tr>
            <th class="text-center">No</th>
            <th class="text-center">Nama</th>
            <th class="text-center">Pangkat Baru</th>
            <th class="text-center">Pejabat SK</th>
            <th class="text-center">Tanggal SK</th>
            <th class="text-center">No SK</th>
            <th class="text-center">Tanggal Berlaku</th>
            <th class="text-center">MS Kerja Baru</th>
            <th class="text-center">Gaji Pokok Lama</th>
            <th class="text-center">Gaji Pokok</th>
            <th class="text-center">PP Lama</th>
            <th class="text-center">Keterangan</th>
        </tr>
        </table>
        </div>
