 <!-- Begin Page Content -->
 <div class="container-fluid">

<!-- Page Heading -->
<div class="container-fluid">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo $title?></h1> 
        </div>

        <!-- NAVBAR --> 
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link" href="<?php echo base_url('administrator/daftar_urut_kepangkatan/')?>">Data Pegawai</a>
            <a class="nav-item nav-link" href="<?php echo base_url('administrator/karir/')?>">Karir</a>
            <a class="nav-item nav-link" href="<?php echo base_url('administrator/pendidikan/')?>">Pendidikan</a>
            <a class="nav-item nav-link active" href="<?php echo base_url('administrator/data_umum/')?>">Data Umum <span class="sr-only">(current)</span></a>
            <a class="nav-item nav-link" href="<?php echo base_url('administrator/alamat/')?>">Alamat</a>
            <a class="nav-item nav-link" href="<?php echo base_url('administrator/penghargaan/')?>">Penghargaan</a>
            <a class="nav-item nav-link " href="<?php echo base_url('administrator/keterangan/')?>">Keterangan</a>
        </div>
        </div>
        </nav>  

        <!-- Button Tambah Data  -->
            <a class="btn btn-sm mb-3 btn-success " href="<?php echo base_url('administrator/daftar_urut_kepangkatan/tambah_data_pegawai/')?>">
            <i class="fas fa-plus"> Tambah Data</i></a>
            <?php echo $this->session->flashdata('pesan')?>  
    <div class="table-responsive">          
       <table class="table table-bordered table-striped mt-2">
        <tr>

            <!-- Tabel Data -->

            <!-- Data Pegawai -->
            <th class="text-center">No</th>
            <th class="text-center">NIP</th>
            <th class="text-center">Nama</th>

            <!-- Data Umum -->
            <th class="text-center">Tempat Lahir</th>
            <th class="text-center">Tanggal Lahir</th>
            <th class="text-center">Jenis Kelamin</th>
            <th class="text-center">Agama</th>
            <th class="text-center">Status Perkawinan</th>

            <th class="text-center">Action</th>

          

        </tr>

        <!-- Menampilkan Data Ke Tabel -->
        <?php $no=1; foreach($daftar_pangkat as $d) :?>
            <tr>
                <!-- Data Pegawai -->
                <td><?php echo $no++ ?></td>
                <td><?php echo number_format ($d-> nip, 0, '','')?></td>
                <td><?php echo $d-> nama?></td>
                
                 <!-- Data Umum -->
                <td><?php echo $d-> tempat_lahir?></td>
                <td><?php echo $d-> tanggal_lahir?></td>
                <td><?php echo $d-> jenis_kelamin?></td>
                <td><?php echo $d-> agama?></td>
                <td><?php echo $d-> status_perkawinan?></td>


                <!-- Tombol Update dan Edit Data-->
                <td>
                <div class="btn-group">
                <!-- Update Data -->
                <a class="btn btn-sm btn-primary" href="<?php echo base_url('administrator/daftar_urut_kepangkatan/update_data_pegawai/'.$d->id_pegawai)?>">
                    <i class="fas fa-edit"></i>
                </a>
                <!-- Delete Data -->
                <a onclick="return confirm('Apakah Anda Ingin Menghapusnya??')" class="btn btn-sm btn-danger" href="<?php echo base_url('administrator/daftar_urut_kepangkatan/delete_data/'.$d->id_pegawai)?>">
                    <i class="fas fa-trash"></i>
                </a>
                </div>
                <style>.btn-group {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    }

                    .btn-group .btn {
                        margin-right: 5px;
                    }
                </style>
                    
                </td>
            </tr>
            <?php endforeach; ?>
    </table>
        </div>
        </div>
        </div>
